# digital-clock

本项目旨在帮助同学们**快速**完成**EEE116**数字时钟的代码开发。<br/>
[**开发文档在这里**](https://digitalclock.eee.dog)


> 感谢[番茄树](https://tomatotrees.xyz)、晓天、[obsverrr](https://github.com/Obsverrr)、[FelderMountain](https://github.com/FelderMountain)、江南等同学对本项目的无私贡献~
